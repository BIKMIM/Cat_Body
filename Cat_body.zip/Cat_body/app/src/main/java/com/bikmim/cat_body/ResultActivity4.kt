package com.bikmim.cat_body

import androidx.appcompat.app.AppCompatActivity
import android.os.Bundle
import android.text.method.ScrollingMovementMethod
import com.bikmim.cat_body.databinding.ActivityResult4Binding

class ResultActivity4 : AppCompatActivity() {
    private lateinit var r4Binding : ActivityResult4Binding

    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)

        r4Binding = ActivityResult4Binding.inflate(layoutInflater)
        setContentView(r4Binding.root)

        // 스크롤 만들기
        r4Binding.tv4StatusText.movementMethod = ScrollingMovementMethod.getInstance()
        r4Binding.tv4DiagText.movementMethod = ScrollingMovementMethod.getInstance()

        //스크롤 제일 위로 올리기
        r4Binding.tv4StatusText.scrollY = 0

        //스크롤 제일 위로 올리기
        r4Binding.tv4DiagText.scrollY = 0
    }
}