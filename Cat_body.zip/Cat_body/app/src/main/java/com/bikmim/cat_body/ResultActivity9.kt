package com.bikmim.cat_body

import androidx.appcompat.app.AppCompatActivity
import android.os.Bundle
import android.text.method.ScrollingMovementMethod
import com.bikmim.cat_body.databinding.ActivityResult9Binding

class ResultActivity9 : AppCompatActivity() {
    private lateinit var r9Binding : ActivityResult9Binding

    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)

        r9Binding = ActivityResult9Binding.inflate(layoutInflater)
        setContentView(r9Binding.root)

        // 스크롤 만들기
        r9Binding.tv9StatusText.movementMethod = ScrollingMovementMethod.getInstance()
        r9Binding.tv9DiagText.movementMethod = ScrollingMovementMethod.getInstance()

        //스크롤 제일 위로 올리기
        r9Binding.tv9StatusText.scrollY = 0

        //스크롤 제일 위로 올리기
        r9Binding.tv9DiagText.scrollY = 0

    }
}