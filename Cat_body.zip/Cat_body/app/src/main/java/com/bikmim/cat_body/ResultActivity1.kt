package com.bikmim.cat_body

import androidx.appcompat.app.AppCompatActivity
import android.os.Bundle
import android.text.method.ScrollingMovementMethod
import com.bikmim.cat_body.databinding.ActivityResult1Binding

class ResultActivity1 : AppCompatActivity() {

    private lateinit var r1Binding : ActivityResult1Binding

    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)

        r1Binding = ActivityResult1Binding.inflate(layoutInflater)
        setContentView(r1Binding.root)

        // 스크롤 만들기
        r1Binding.tv1StatusText.movementMethod = ScrollingMovementMethod.getInstance()
        r1Binding.tv1DiagText.movementMethod = ScrollingMovementMethod.getInstance()

        //스크롤 제일 위로 올리기
        r1Binding.tv1StatusText.scrollY = 0

        //스크롤 제일 위로 올리기
        r1Binding.tv1DiagText.scrollY = 0

    }
}