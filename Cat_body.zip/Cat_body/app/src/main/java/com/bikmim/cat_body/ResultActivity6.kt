package com.bikmim.cat_body

import androidx.appcompat.app.AppCompatActivity
import android.os.Bundle
import android.text.method.ScrollingMovementMethod
import com.bikmim.cat_body.databinding.ActivityResult6Binding

class ResultActivity6 : AppCompatActivity() {
    private lateinit var r6Binding : ActivityResult6Binding

    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)

        r6Binding = ActivityResult6Binding.inflate(layoutInflater)
        setContentView(r6Binding.root)

        // 스크롤 만들기
        r6Binding.tv6StatusText.movementMethod = ScrollingMovementMethod.getInstance()
        r6Binding.tv6DiagText.movementMethod = ScrollingMovementMethod.getInstance()

        //스크롤 제일 위로 올리기
        r6Binding.tv6StatusText.scrollY = 0

        //스크롤 제일 위로 올리기
        r6Binding.tv6DiagText.scrollY = 0
    }
}