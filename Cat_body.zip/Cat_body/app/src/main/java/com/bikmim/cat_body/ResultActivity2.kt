package com.bikmim.cat_body

import androidx.appcompat.app.AppCompatActivity
import android.os.Bundle
import android.text.method.ScrollingMovementMethod
import com.bikmim.cat_body.databinding.ActivityResult2Binding

class ResultActivity2 : AppCompatActivity() {
    private lateinit var r2Binding : ActivityResult2Binding

    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)

        r2Binding = ActivityResult2Binding.inflate(layoutInflater)
        setContentView(r2Binding.root)

        // 스크롤 만들기
        r2Binding.tv2StatusText.movementMethod = ScrollingMovementMethod.getInstance()
        r2Binding.tv2DiagText.movementMethod = ScrollingMovementMethod.getInstance()

        //스크롤 제일 위로 올리기
        r2Binding.tv2StatusText.scrollY = 0

        //스크롤 제일 위로 올리기
        r2Binding.tv2DiagText.scrollY = 0
    }
}