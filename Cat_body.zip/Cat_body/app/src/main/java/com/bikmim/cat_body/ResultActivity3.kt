package com.bikmim.cat_body

import androidx.appcompat.app.AppCompatActivity
import android.os.Bundle
import android.text.method.ScrollingMovementMethod
import com.bikmim.cat_body.databinding.ActivityResult3Binding

class ResultActivity3 : AppCompatActivity() {
    private lateinit var r3Binding : ActivityResult3Binding

    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)

        r3Binding = ActivityResult3Binding.inflate(layoutInflater)
        setContentView(r3Binding.root)

        // 스크롤 만들기
        r3Binding.tv3StatusText.movementMethod = ScrollingMovementMethod.getInstance()
        r3Binding.tv3DiagText.movementMethod = ScrollingMovementMethod.getInstance()

        //스크롤 제일 위로 올리기
        r3Binding.tv3StatusText.scrollY = 0


        //스크롤 제일 위로 올리기
        r3Binding.tv3DiagText.scrollY = 0
    }
}