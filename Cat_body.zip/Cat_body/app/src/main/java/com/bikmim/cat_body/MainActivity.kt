package com.bikmim.cat_body

import android.content.Intent
import androidx.appcompat.app.AppCompatActivity
import android.os.Bundle
import android.widget.Toast
import com.bikmim.cat_body.databinding.ActivityMainBinding




class MainActivity : AppCompatActivity() {

    private lateinit var mBinding : ActivityMainBinding

    var bmiResult = 0.0
    private var bodyMeasure : Float? = null
    private var legMeasure : Float? = null


    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)

        // 키바인딩
        mBinding = ActivityMainBinding.inflate(layoutInflater)
        setContentView(mBinding.root)




        // Main -> ResultActivity1 로 이동
        fun moveResultActivity1() {
            val intent = Intent(this, ResultActivity1::class.java)
            startActivity(intent)
        }

        fun moveResultActivity2() {
            val intent = Intent(this, ResultActivity2::class.java)
            startActivity(intent)
        }

        fun moveResultActivity3() {
            val intent = Intent(this, ResultActivity3::class.java)
            startActivity(intent)
        }

        fun moveResultActivity4() {
            val intent = Intent(this, ResultActivity4::class.java)
            startActivity(intent)
        }

        fun moveResultActivity5() {
            val intent = Intent(this, ResultActivity5::class.java)
            startActivity(intent)
        }

        fun moveResultActivity6() {
            val intent = Intent(this, ResultActivity6::class.java)
            startActivity(intent)
        }

        fun moveResultActivity7() {
            val intent = Intent(this, ResultActivity7::class.java)
            startActivity(intent)
        }

        fun moveResultActivity8() {
            val intent = Intent(this, ResultActivity8::class.java)
            startActivity(intent)
        }

        fun moveResultActivity9() {
            val intent = Intent(this, ResultActivity9::class.java)
            startActivity(intent)
        }


        // bmi 계산
        fun bmiCalc() {

            // 변수 할당
            bodyMeasure = mBinding.etBodyMeasure.text.toString().toFloat()
            legMeasure = mBinding.etLegMeasure.text.toString().toFloat()


            val c1 = 0.7062
            val c2 = 0.9156

            if (bodyMeasure != null && legMeasure != null) {
                bmiResult = ((((bodyMeasure!! / c1) - legMeasure!!) / c2) - legMeasure!!)
                Toast.makeText(this, "결과는 $bmiResult 입니다.", Toast.LENGTH_SHORT).show()

                // bmiResult에 따라서 Activity 이동
                when (bmiResult) {
                    in -1000.0..-11.0027229337 -> moveResultActivity1() // 심각한 저체중
                    in -11.0027229336..-0.4515191478 -> moveResultActivity2() // 저체중
                    in -0.4515191477..10.0093808085 -> moveResultActivity3() // 마름
                    in 10.0093808086..19.9284577874 -> moveResultActivity4() // 정상
                    in 19.9284577875..29.5690273220 -> moveResultActivity5() // 정상
                    in 29.5690273221..42.9424376913 -> moveResultActivity6() // 통통
                    in 42.9424376914..54.3139718989 -> moveResultActivity7() // 과체중
                    in 54.3139718990..66.6864441873 -> moveResultActivity8() // 비만
                    in 66.6864441874..1000.0 -> moveResultActivity9() // 심각한 비만
                }
            }
        }

        // 계산하기 버튼 눌렀을 때 bmiCalc 계산
        mBinding.calcBtn.setOnClickListener {
            bmiCalc()
        }
    }
}
