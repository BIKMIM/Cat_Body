package com.bikmim.cat_body

import androidx.appcompat.app.AppCompatActivity
import android.os.Bundle
import android.text.method.ScrollingMovementMethod
import com.bikmim.cat_body.databinding.ActivityResult7Binding

class ResultActivity7 : AppCompatActivity() {
    private lateinit var r7Binding : ActivityResult7Binding

    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)

        r7Binding = ActivityResult7Binding.inflate(layoutInflater)
        setContentView(r7Binding.root)

        // 스크롤 만들기
        r7Binding.tv7StatusText.movementMethod = ScrollingMovementMethod.getInstance()
        r7Binding.tv7DiagText.movementMethod = ScrollingMovementMethod.getInstance()

        //스크롤 제일 위로 올리기
        r7Binding.tv7StatusText.scrollY = 0

        //스크롤 제일 위로 올리기
        r7Binding.tv7DiagText.scrollY = 0
    }
}