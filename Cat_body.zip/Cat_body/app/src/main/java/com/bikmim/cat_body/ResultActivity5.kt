package com.bikmim.cat_body

import androidx.appcompat.app.AppCompatActivity
import android.os.Bundle
import android.text.method.ScrollingMovementMethod
import com.bikmim.cat_body.databinding.ActivityResult5Binding

class ResultActivity5 : AppCompatActivity() {
    private lateinit var r5Binding : ActivityResult5Binding

    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)

        r5Binding = ActivityResult5Binding.inflate(layoutInflater)
        setContentView(r5Binding.root)

        // 스크롤 만들기
        r5Binding.tv5StatusText.movementMethod = ScrollingMovementMethod.getInstance()
        r5Binding.tv5DiagText.movementMethod = ScrollingMovementMethod.getInstance()

        //스크롤 제일 위로 올리기
        r5Binding.tv5StatusText.scrollY = 0

        //스크롤 제일 위로 올리기
        r5Binding.tv5DiagText.scrollY = 0
    }
}